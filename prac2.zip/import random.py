import random
dir(random)

